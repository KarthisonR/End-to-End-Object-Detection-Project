# ojbect detectio > 2024-08-16 12:52pm
https://universe.roboflow.com/end-to-end-project/ojbect-detectio

Provided by a Roboflow user
License: CC BY 4.0

